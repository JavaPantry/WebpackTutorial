# Webpack step by step
A Beginner�s Guide to Webpack 4 and Module Bundling
https://www.sitepoint.com/beginners-guide-webpack-module-bundling/
src https://github.com/markbrown4/webpack-demo

v#0.1
Q05459@M005554MIS MINGW64 /c/IntelliJ_WS_tutorials
$ mkdir webpack-demo && cd webpack-demo
$ npm init -y
$ npm install --save-dev webpack webpack-cli
$ mkdir dist
$ mkdir src

add index.js and index.html as in article
add webpack.config.js as in article
add script section to package.json

$ npm run develop

v#0.2
- import lodash-es to use groupBy
	- Lodash makes JavaScript easier by taking the hassle out of working with arrays, numbers, objects, strings, etc.
	- see: https://lodash.com/  and https://github.com/lodash/lodash/tree/es
- demo import/export modules
